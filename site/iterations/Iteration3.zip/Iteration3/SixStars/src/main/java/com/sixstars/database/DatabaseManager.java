package com.sixstars.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

public class DatabaseManager {
    private static final String DB_NAME = "hotel_reservation.db";
    private static String databasePath;

    static {
        // Initialize the database path on class load
        databasePath = initializeDatabasePath();
    }

    private static String initializeDatabasePath() {
        // Check if database exists in current working directory
        File dbFile = new File(DB_NAME);
        if (dbFile.exists()) {
            return "jdbc:sqlite:" + DB_NAME;
        }

        // Otherwise, extract from bundled resources
        try {
            InputStream resourceStream = DatabaseManager.class.getResourceAsStream("/data/" + DB_NAME);
            if (resourceStream != null) {
                Files.createDirectories(Paths.get("."));
                Files.copy(resourceStream, Paths.get(DB_NAME));
                System.out.println("Extracted bundled database: " + DB_NAME);
                return "jdbc:sqlite:" + DB_NAME;
            }
        } catch (Exception e) {
            System.err.println("Warning: Could not extract bundled database: " + e.getMessage());
        }

        // Fallback to creating a new database file
        System.out.println("Creating new database: " + DB_NAME);
        return "jdbc:sqlite:" + DB_NAME;
    }

    private static final String URL = databasePath;

    public static Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(URL);
        try (Statement pragma = conn.createStatement()) {
            pragma.execute("PRAGMA foreign_keys = ON");
        }
        return conn;
    }

    public static void initializeDatabase() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            boolean addedAccountVerificationColumns = false;

            // Create Accounts Table
            stmt.execute("CREATE TABLE IF NOT EXISTS accounts (" +
                    "email TEXT PRIMARY KEY, firstName TEXT, lastName TEXT, " +
                    "passwordHash TEXT, role TEXT, profileImagePath TEXT)");

//            stmt.execute("ALTER TABLE reservations ADD COLUMN status TEXT DEFAULT 'BOOKED'");
            // Create Rooms Table
            stmt.execute("CREATE TABLE IF NOT EXISTS rooms (" +
                    "roomNumber INTEGER PRIMARY KEY, bedType TEXT, " +
                    "theme TEXT, qualityLevel TEXT, isSmoking INTEGER, pricePerNight INTEGER DEFAULT 0)");

            // Create Reservations Table
            stmt.execute("CREATE TABLE IF NOT EXISTS reservations (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, startDate TEXT, endDate TEXT, guestEmail TEXT, " +
                    "nightlyRate INTEGER DEFAULT 0, nights INTEGER DEFAULT 0, totalCost INTEGER DEFAULT 0, " +
                    "status TEXT DEFAULT 'BOOKED', createdDate TEXT)");

            // Create Join Table for Reservation <-> Rooms (Many-to-Many)
            stmt.execute("CREATE TABLE IF NOT EXISTS reservation_rooms (" +
                    "reservation_id INTEGER NOT NULL, room_number INTEGER NOT NULL, " +
                    "PRIMARY KEY (reservation_id, room_number), " +
                    "FOREIGN KEY(reservation_id) REFERENCES reservations(id), " +
                    "FOREIGN KEY(room_number) REFERENCES rooms(roomNumber))");
            // Create Shop Items Table
            stmt.execute("CREATE TABLE IF NOT EXISTS shop_items (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT NOT NULL UNIQUE, " +
                    "price REAL NOT NULL, " +
                    "stock INTEGER NOT NULL, " +
                    "imagePath TEXT)");

            // Create persisted cart table
            stmt.execute("CREATE TABLE IF NOT EXISTS shop_cart_items (" +
                    "guestEmail TEXT NOT NULL, " +
                    "item_id INTEGER NOT NULL, " +
                    "quantity INTEGER NOT NULL DEFAULT 1, " +
                    "PRIMARY KEY (guestEmail, item_id), " +
                    "FOREIGN KEY(guestEmail) REFERENCES accounts(email) ON DELETE CASCADE, " +
                    "FOREIGN KEY(item_id) REFERENCES shop_items(id) ON DELETE CASCADE)");

            addColumnIfMissing(conn, "rooms", "pricePerNight", "INTEGER DEFAULT 0");
            addColumnIfMissing(conn, "reservations", "nightlyRate", "INTEGER DEFAULT 0");
            addColumnIfMissing(conn, "reservations", "nights", "INTEGER DEFAULT 0");
            addColumnIfMissing(conn, "reservations", "totalCost", "INTEGER DEFAULT 0");
            addColumnIfMissing(conn, "reservations", "status", "TEXT DEFAULT 'BOOKED'");
            addColumnIfMissing(conn, "reservations", "createdDate", "TEXT");

            addedAccountVerificationColumns |= addColumnIfMissing(conn, "accounts", "email_verified", "INTEGER DEFAULT 0");
            addedAccountVerificationColumns |= addColumnIfMissing(conn, "accounts", "verification_code_hash", "TEXT");
            addedAccountVerificationColumns |= addColumnIfMissing(conn, "accounts", "verification_expires_at", "TEXT");

            if (addedAccountVerificationColumns) {
                try (Statement backfillStmt = conn.createStatement()) {
                    backfillStmt.executeUpdate("UPDATE accounts SET email_verified = 1");
                }
            }
            addColumnIfMissing(conn, "accounts", "profileImagePath", "TEXT");
            addColumnIfMissing(conn, "reservations", "maxDailyRate", "INTEGER DEFAULT 0");
            addColumnIfMissing(conn, "reservations", "ratePlan", "TEXT DEFAULT 'STANDARD'");
            ensureReservationRoomsForeignKey(conn);

            stmt.execute("CREATE TABLE IF NOT EXISTS saved_payment_methods (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "guest_email TEXT NOT NULL, " +
                    "nickname TEXT, " +
                    "card_brand TEXT NOT NULL, " +
                    "last_four TEXT NOT NULL, " +
                    "exp_month INTEGER NOT NULL, " +
                    "exp_year INTEGER NOT NULL, " +
                    "name_on_card TEXT NOT NULL, " +
                    "line1 TEXT NOT NULL, " +
                    "line2 TEXT, " +
                    "city TEXT NOT NULL, " +
                    "state TEXT NOT NULL, " +
                    "zip TEXT NOT NULL, " +
                    "phone TEXT, " +
                    "created_at TEXT NOT NULL)");

            stmt.execute("CREATE TABLE IF NOT EXISTS guest_payments (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "guest_email TEXT NOT NULL, " +
                    "amount REAL NOT NULL, " +
                    "payment_kind TEXT NOT NULL, " +
                    "method_summary TEXT NOT NULL, " +
                    "saved_method_id INTEGER, " +
                    "created_at TEXT NOT NULL)");

            ensureShopImagePaths(conn);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Binds shop item rows to classpath image assets so thumbnails work regardless of process working directory.
     */
    private static void ensureShopImagePaths(Connection conn) throws SQLException {
        updateShopImageIfMatch(conn, "%water%", "/assets/shopImages/water.png");
        updateShopImageIfMatch(conn, "%chip%", "/assets/shopImages/chips.png");
        updateShopImageIfMatch(conn, "%tooth%", "/assets/shopImages/toothbrush.png");
        updateShopImageIfMatch(conn, "%snack%", "/assets/shopImages/snack.png");
        updateShopImageIfMatch(conn, "%coffee%", "/assets/shopImages/coffee.png");
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE shop_items SET imagePath = ? WHERE imagePath IS NULL OR TRIM(imagePath) = ''")) {
            ps.setString(1, "/assets/shopImages/default.png");
            ps.executeUpdate();
        }
    }

    private static void updateShopImageIfMatch(Connection conn, String nameLike, String classpathImage)
            throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE shop_items SET imagePath = ? WHERE lower(name) LIKE ?")) {
            ps.setString(1, classpathImage);
            ps.setString(2, nameLike);
            ps.executeUpdate();
        }
    }

    private static void ensureReservationRoomsForeignKey(Connection conn) throws SQLException {
        boolean foundRoomForeignKey = false;
        boolean needsMigration = false;

        try (Statement pragmaStmt = conn.createStatement();
             ResultSet rs = pragmaStmt.executeQuery("PRAGMA foreign_key_list(reservation_rooms)")) {
            while (rs.next()) {
                String referencedTable = rs.getString("table");
                String fromColumn = rs.getString("from");
                String toColumn = rs.getString("to");

                if ("rooms".equalsIgnoreCase(referencedTable) && "room_number".equalsIgnoreCase(fromColumn)) {
                    foundRoomForeignKey = true;
                    if (!"roomNumber".equalsIgnoreCase(toColumn)) {
                        needsMigration = true;
                    }
                }
            }
        }

        if (!foundRoomForeignKey) {
            needsMigration = true;
        }

        if (!needsMigration) {
            return;
        }

        try (Statement migrationStmt = conn.createStatement()) {
            migrationStmt.execute("PRAGMA foreign_keys=OFF");
            migrationStmt.execute("BEGIN TRANSACTION");
            migrationStmt.execute("ALTER TABLE reservation_rooms RENAME TO reservation_rooms_old");
            migrationStmt.execute("CREATE TABLE reservation_rooms (" +
                    "reservation_id INTEGER NOT NULL, room_number INTEGER NOT NULL, " +
                    "PRIMARY KEY (reservation_id, room_number), " +
                    "FOREIGN KEY (reservation_id) REFERENCES reservations(id), " +
                    "FOREIGN KEY (room_number) REFERENCES rooms(roomNumber))");
            migrationStmt.execute("INSERT INTO reservation_rooms (reservation_id, room_number) " +
                    "SELECT reservation_id, room_number FROM reservation_rooms_old");
            migrationStmt.execute("DROP TABLE reservation_rooms_old");
            migrationStmt.execute("COMMIT");
            migrationStmt.execute("PRAGMA foreign_keys=ON");
        } catch (SQLException migrationError) {
            try (Statement rollbackStmt = conn.createStatement()) {
                rollbackStmt.execute("ROLLBACK");
                rollbackStmt.execute("PRAGMA foreign_keys=ON");
            } catch (SQLException ignored) {
                // If rollback fails, rethrow original migration error.
            }
            throw migrationError;
        }
    }

    private static boolean addColumnIfMissing(Connection conn, String tableName, String columnName, String columnDefinition)
            throws SQLException {
        String pragmaSql = "PRAGMA table_info(" + tableName + ")";
        boolean columnExists = false;

        try (Statement pragmaStmt = conn.createStatement();
             ResultSet rs = pragmaStmt.executeQuery(pragmaSql)) {
            while (rs.next()) {
                if (columnName.equalsIgnoreCase(rs.getString("name"))) {
                    columnExists = true;
                    break;
                }
            }
        }

        if (!columnExists) {
            try (Statement alterStmt = conn.createStatement()) {
                alterStmt.execute("ALTER TABLE " + tableName + " ADD COLUMN " + columnName + " " + columnDefinition);
            }
            return true;
        }

        return false;
    }
}